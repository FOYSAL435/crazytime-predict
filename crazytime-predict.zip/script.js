function predict() {
  const outcomes = ['1', '2', '5', '10', 'Coin Flip', 'Cash Hunt', 'Pachinko', 'Crazy Time'];
  const result = outcomes[Math.floor(Math.random() * outcomes.length)];
  document.getElementById("result").innerText = "Next Prediction: " + result;
}